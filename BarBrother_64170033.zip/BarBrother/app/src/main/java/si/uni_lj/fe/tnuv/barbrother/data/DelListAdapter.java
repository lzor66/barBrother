package si.uni_lj.fe.tnuv.barbrother.data;

import android.os.Build;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;

import java.util.Locale;

import si.uni_lj.fe.tnuv.barbrother.DelViewHolder;

public class DelListAdapter extends ListAdapter<Del, DelViewHolder> {

    public DelListAdapter(@NonNull DiffUtil.ItemCallback<Del> diffCallback){
        super(diffCallback);
    }

    @NonNull
    @Override
    public DelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        return DelViewHolder.create(parent);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(DelViewHolder holder, int position){
        Del current = getItem(position);
        holder.bind(current.imeDela.toUpperCase(Locale.ROOT) + " - DNEVI OD ZADNJE VADBE : " + current.dnevovOdZadnje,
                current);
    }

    public static class DelDiff extends DiffUtil.ItemCallback<Del>{
        @Override
        public boolean areItemsTheSame(@NonNull Del delStar, @NonNull Del delNov){
            return delStar == delNov;
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        public boolean areContentsTheSame(@NonNull Del delStar, @NonNull Del delNov) {
            return delStar.getName().equals(delNov.getName());
        }
    }
}
