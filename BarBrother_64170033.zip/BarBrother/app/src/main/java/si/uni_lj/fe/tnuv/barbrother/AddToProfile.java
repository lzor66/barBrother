package si.uni_lj.fe.tnuv.barbrother;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class AddToProfile extends AppCompatActivity{

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_to_profile);

        Spinner spinner = findViewById(R.id.spinner);
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("LAHKO (1-2 NA TEDEN)");
        arrayList.add("SREDNJE (3-4 NA TEDEN)");
        arrayList.add("NAPREDNO (5-7 NA TEDEN)");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, arrayList);
        arrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);

        FloatingActionButton konec = findViewById(R.id.addToProfileFinishButton);
        konec.setOnClickListener(view -> activityInsertAndFinish());
    }

    @SuppressLint("SimpleDateFormat")
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void activityInsertAndFinish() {
        TextView ime = findViewById(R.id.textInputEditText);
        if (ime.getText().toString().equals("")) {
            Toast opozorilo = Toast.makeText(this, "Vnesite ime dela telesa", Toast.LENGTH_LONG);
            opozorilo.show();
        }
        else {
            Intent odgovor = new Intent();
            String imeDela = ime.getText().toString();

            long zadnji = System.currentTimeMillis()/(1000*60*60*24);
            String zadnjiDatum = String.valueOf(zadnji);

            Spinner spn = findViewById(R.id.spinner);
            int position = spn.getSelectedItemPosition();
            String casOpomnik = "";
            switch(position) {
                case 0: casOpomnik = Integer.toString(6);
                break;

                case 1: casOpomnik = Integer.toString(4);
                    break;

                case 2: casOpomnik = Integer.toString(2);
                    break;
            }
            String[] delSeznam = {imeDela, zadnjiDatum, casOpomnik};
            odgovor.putExtra("del", delSeznam);
            setResult(RESULT_OK, odgovor);
            finish();

        }
    }

}