package si.uni_lj.fe.tnuv.barbrother.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Del.class}, version = 1, exportSchema = false)
public abstract class DelDatabase extends RoomDatabase {
    public abstract DelDao delDao();

    private static volatile DelDatabase INSTANCE;
    private static final int threads = 4;
    static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(threads);

    static DelDatabase getDatabase(final Context context){
        if(INSTANCE == null){
            synchronized (DelDatabase.class){
                if(INSTANCE == null){
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), DelDatabase.class, "del_database").build();
                }
            }
        }
        return INSTANCE;
    }
}
