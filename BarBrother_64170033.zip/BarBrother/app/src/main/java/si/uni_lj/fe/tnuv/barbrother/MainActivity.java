package si.uni_lj.fe.tnuv.barbrother;

import static java.lang.Long.parseLong;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;

import si.uni_lj.fe.tnuv.barbrother.data.Del;
import si.uni_lj.fe.tnuv.barbrother.data.DelListAdapter;
import si.uni_lj.fe.tnuv.barbrother.data.DelViewModel;

public class MainActivity extends AppCompatActivity {

    public static DelViewModel dViewModel;
    public long danes;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.mainActivityRecyclerView);
        final DelListAdapter adapter = new DelListAdapter(new DelListAdapter.DelDiff());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        danes = System.currentTimeMillis()/(1000*60*60*24);
        dViewModel = new ViewModelProvider(this).get(DelViewModel.class);
        dViewModel.getAll().observe(this, deli ->{
            adapter.submitList(deli);
            if(!deli.isEmpty()) {
                Del del = deli.get(0);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if(parseLong(del.zadnjiDatum) != danes) {
                        dViewModel.update();
                    }
                }
            }
        });

        FloatingActionButton dodaj = findViewById(R.id.mainActivityAddButton);
        dodaj.setOnClickListener(view -> activityAddToProfile());
    }

    protected void onRestart() {
        super.onRestart();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dViewModel.update();
        }
    }

    public static final int ADD_TO_PROFILE_ACTIVITY_REQUEST_CODE = 1;


    public void activityAddToProfile() {
        Intent switchActivityIntent = new Intent(this, AddToProfile.class);
        startActivityForResult(switchActivityIntent, ADD_TO_PROFILE_ACTIVITY_REQUEST_CODE);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == ADD_TO_PROFILE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK){
            Del del = new Del();
            String[] rezultat = data.getStringArrayExtra("del");
            del.imeDela = rezultat[0];
            del.zadnjiDatum = rezultat[1];
            del.casOpomnik = Integer.parseInt(rezultat[2]);
            try {
                del.dnevovOdZadnje = del.vmesniDnevi(rezultat[1]);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            dViewModel.insert(del);
        }
    }

}