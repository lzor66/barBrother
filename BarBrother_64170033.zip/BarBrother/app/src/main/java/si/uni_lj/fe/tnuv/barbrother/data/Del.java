package si.uni_lj.fe.tnuv.barbrother.data;

import static java.lang.Long.parseLong;

import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.text.ParseException;

@RequiresApi(api = Build.VERSION_CODES.O)
@Entity
public class Del {
    @PrimaryKey(autoGenerate = true)
    public Integer id;

    @ColumnInfo(name = "ime_dela")
    public String imeDela;

    @ColumnInfo(name = "cas_opomnik")
    public int casOpomnik;

    @ColumnInfo(name = "zadnji_datum")
    public String zadnjiDatum;

    @ColumnInfo(name = "dnevov_od_zadnje_vadbe")
    public long dnevovOdZadnje;

    public String getName(){return this.imeDela;}

    @RequiresApi(api = Build.VERSION_CODES.O)
    public long vmesniDnevi(String datumZadnji) throws ParseException {
        long danes = System.currentTimeMillis()/(1000*60*60*24);
        long zadnji = parseLong(datumZadnji);
        return danes-zadnji;
    }
}
