package si.uni_lj.fe.tnuv.barbrother.data;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class DelRepository {
    private final DelDao dao;
    private final LiveData<List<Del>> seznamDelov;

    DelRepository(Application application){
        DelDatabase db = DelDatabase.getDatabase(application);
        dao = db.delDao();
        seznamDelov = dao.getAll();
    }

    LiveData<List<Del>> getAll(){
        return seznamDelov;
    }

    void insert(Del del){
        DelDatabase.databaseWriteExecutor.execute(() -> dao.insert(del));
    }

    void update(Del del){
        DelDatabase.databaseWriteExecutor.execute(() -> dao.update(del));
    }

    void delete(Del del){
        DelDatabase.databaseWriteExecutor.execute(() -> dao.delete(del));
    }
}
