package si.uni_lj.fe.tnuv.barbrother;

import android.app.Dialog;
import android.graphics.Color;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import si.uni_lj.fe.tnuv.barbrother.data.Del;
import si.uni_lj.fe.tnuv.barbrother.data.DelViewModel;

public class DelViewHolder extends RecyclerView.ViewHolder {
    private final TextView delItemView;
    private final DelViewModel model;

    private DelViewHolder(View itemView){
        super(itemView);
        model = MainActivity.dViewModel;
        delItemView = itemView.findViewById(R.id.textViewIme);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void bind(String text, Del del){
        delItemView.setText(text);
        if(del.dnevovOdZadnje<del.casOpomnik){
            delItemView.setBackgroundColor(Color.GREEN);
        }
        else if(del.dnevovOdZadnje<2*del.casOpomnik){
            delItemView.setBackgroundColor(Color.YELLOW);
        }
        else{
            delItemView.setBackgroundColor(Color.RED);
        }
        delItemView.setOnClickListener(v -> recyclerElementOptions(del));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void recyclerElementOptions(Del del) {
        Dialog dialog;
        dialog = new Dialog(delItemView.getContext());
        dialog.setContentView(R.layout.recycler_popup);
        dialog.show();

        Button izbrisi = dialog.findViewById(R.id.buttonIzbrisi);
        Button posodobi = dialog.findViewById(R.id.buttonPosodobi);

        izbrisi.setOnClickListener(v -> {
            model.delete(del);
            dialog.dismiss();
        });

        posodobi.setOnClickListener(v -> {
            del.zadnjiDatum = String.valueOf(System.currentTimeMillis()/(1000*60*60*24));
            model.update();
            dialog.dismiss();
        });
    }

    public static DelViewHolder create(ViewGroup parent){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_item, parent, false);
        return new DelViewHolder(view);
    }
}
