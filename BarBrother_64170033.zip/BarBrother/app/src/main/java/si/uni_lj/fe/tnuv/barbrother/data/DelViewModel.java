package si.uni_lj.fe.tnuv.barbrother.data;

import android.app.Application;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.text.ParseException;
import java.util.List;

public class DelViewModel extends AndroidViewModel {
    private final DelRepository repository;
    private final LiveData<List<Del>> seznamDelov;

    public DelViewModel(Application application){
        super(application);
        repository = new DelRepository(application);
        seznamDelov = repository.getAll();
    }

    public LiveData<List<Del>> getAll() { return seznamDelov; }

    public void insert(Del del) { repository.insert(del); }

    public void delete(Del del) { repository.delete(del); }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void update() {
        List<Del> list = seznamDelov.getValue();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if(list != null) {
                list.forEach(del -> {
                    try {
                        del.dnevovOdZadnje = del.vmesniDnevi(del.zadnjiDatum);
                        repository.update(del);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                });
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void isEmpty(){
        List<Del> list = seznamDelov.getValue();
        if(list!=null){
            update();
        }
    }
}
