package si.uni_lj.fe.tnuv.barbrother.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface DelDao {
    @Query("SELECT * FROM del")
    LiveData<List<Del>> getAll();

    @Insert
    void insert(Del del);

    @Delete
    void delete(Del del);

    @Update
    void update(Del del);
}
